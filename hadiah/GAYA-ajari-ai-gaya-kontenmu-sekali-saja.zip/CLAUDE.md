# Gaya konten saya

<!--
Template dari @tinggalbilang.ai (Farid).
Simpan file ini di folder utama proyekmu. Claude Code membacanya otomatis setiap sesi.
Ganti semua bagian [dalam kurung siku] dengan versimu sendiri, lalu hapus komentar ini.
-->

## Tentang akun
- Nama akun: [@namaakun]
- Topik: [contoh: tips masak hemat untuk anak kos]
- Penonton: [contoh: mahasiswa 18–24 tahun, baru belajar masak]
- Janji akun: [contoh: satu resep di bawah 20 ribu, tiap hari]

## Gaya bahasa
- Bahasa Indonesia santai, pakai "aku" dan "kamu".
- Kalimat pendek. Satu kalimat, satu ide.
- Hindari istilah teknis; kalau terpaksa, jelaskan dalam satu kalimat.
- Jangan pakai kata: [kata yang tidak kamu suka, misalnya "guys", "sobat"].

## Aturan naskah video
- Format 9:16, durasi [40–60] detik.
- Hook di kalimat pertama, maksimal 8 kata, berupa pertanyaan atau pernyataan yang membalik anggapan.
- Isi: [3] poin bernomor ("Satu…", "Dua…", "Tiga…").
- Tutup dengan ajakan komen satu kata, misalnya: Komen [KATA], nanti aku kirim lewat DM.

## Aturan caption
- Baris pertama mengulang hook.
- Maksimal [5] hashtag, relevan dengan topik.

## Sebelum menyerahkan hasil
- Cek lagi semua fakta, angka, dan nama produk.
- Tunjukkan dulu ke saya sebelum membuat lebih dari satu versi.
