---
name: naskah-reels
description: Menulis naskah video Reels/TikTok 9:16 berbahasa Indonesia ke naskah.json, dengan hook pendek, 3 poin bernomor, dan ajakan komen satu kata. Pakai saat diminta membuat ide, naskah, atau mengisi naskah.json untuk banyak video sekaligus.
---

# Menulis naskah Reels

Skill dari @tinggalbilang.ai (Farid). Simpan folder ini di `.claude/skills/naskah-reels/` di proyekmu.

## Sebelum menulis
1. Baca `CLAUDE.md` di proyek ini (jika ada) untuk gaya bahasa, topik, dan penonton.
2. Baca `naskah.json` untuk melihat format dan kunci terakhir (misalnya `v03`), supaya nomor berikutnya berlanjut.
3. Kalau topik atau penonton belum jelas, tanyakan dulu satu pertanyaan singkat. Jangan menebak.

## Aturan tiap naskah
- `hook`: maksimal 8 kata. Pertanyaan yang menyentuh masalah penonton, atau pernyataan yang membalik anggapan.
- `poin`: tepat 3 kalimat, masing-masing satu ide yang bisa langsung dipraktikkan, maksimal 15 kata.
- `cta`: "Komen KATA, nanti aku kirim … lewat DM." dengan KATA satu kata huruf kapital.
- `kata_kunci`: sama dengan KATA di `cta`. Jangan dipakai ulang di naskah lain.
- Bahasa santai, pakai "aku" dan "kamu". Tanpa emoji di dalam naskah.
- Jangan mengarang angka, harga, atau fitur produk. Kalau perlu fakta, tulis `[cek]` di tempat itu.

## Saat diminta banyak naskah sekaligus
1. Usulkan dulu daftar judul (misalnya 30 baris) dan tunggu persetujuan.
2. Setelah disetujui, tambahkan semuanya ke `naskah.json` tanpa mengubah naskah yang sudah ada.
3. Pastikan file tetap JSON yang valid, lalu laporkan jumlah naskah baru dan kunci pertama–terakhirnya.
